package com.vishal.linkopener;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Spinner partTwoSpinner;
    private EditText numberInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = dp(22);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setBackgroundColor(0xFFF7F8FA);

        TextView title = new TextView(this);
        title.setText("Vishal Link Opener");
        title.setTextSize(25);
        title.setTextColor(0xFF172033);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(28));
        root.addView(title, matchWrap());

        TextView partTwoLabel = label("Select number (1–12)");
        root.addView(partTwoLabel, matchWrap());

        partTwoSpinner = new Spinner(this);
        String[] options = new String[12];
        for (int i = 0; i < 12; i++) options[i] = String.valueOf(i + 1);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, options
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        partTwoSpinner.setAdapter(adapter);
        root.addView(partTwoSpinner, matchWrap());

        TextView numberLabel = label("Enter 7-digit number");
        LinearLayout.LayoutParams labelParams = matchWrap();
        labelParams.topMargin = dp(22);
        root.addView(numberLabel, labelParams);

        numberInput = new EditText(this);
        numberInput.setSingleLine(true);
        numberInput.setHint("7 digits");
        numberInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        numberInput.setFilters(new InputFilter[] {
            new InputFilter.LengthFilter(7),
            (source, start, end, dest, dstart, dend) -> {
                for (int i = start; i < end; i++) {
                    if (source.charAt(i) < '0' || source.charAt(i) > '9') return "";
                }
                return null;
            }
        });
        root.addView(numberInput, matchWrap());

        Button openButton = new Button(this);
        openButton.setText("OPEN LINK");
        LinearLayout.LayoutParams buttonParams = matchWrap();
        buttonParams.topMargin = dp(28);
        root.addView(openButton, buttonParams);
        openButton.setOnClickListener(v -> openLink());

        setContentView(root);
    }

    private void openLink() {
        String number = numberInput.getText().toString();
        if (number.length() != 7) {
            numberInput.setError("Enter exactly 7 digits");
            return;
        }

        String selected = String.valueOf(partTwoSpinner.getSelectedItem());
        String url = "https://www.vishal.com/2026/" + selected + "/" + number + "/XYZ.PDF";

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            new AlertDialog.Builder(this)
                .setMessage("Could not open the link. Please check that a browser is installed.")
                .setPositiveButton("OK", null)
                .show();
        }
    }

    private TextView label(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(16);
        view.setTextColor(0xFF263247);
        view.setPadding(0, dp(8), 0, dp(6));
        return view;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}

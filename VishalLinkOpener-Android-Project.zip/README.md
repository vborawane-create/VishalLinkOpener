# Vishal Link Opener (Android)

A minimal Android app that combines:
`https://www.vishal.com/2026/` + selected number (1–12) + seven-digit number + `/XYZ.PDF`

Example:
`https://www.vishal.com/2026/5/1234567/XYZ.PDF`

The app validates that the manually entered value contains exactly seven digits, then opens the resulting URL in the phone's browser.

## Build APK from an Android phone using GitHub Actions

1. Create/sign in to a GitHub account in your phone browser.
2. Create a new repository (for example, `VishalLinkOpener`).
3. Upload the contents of this ZIP to the repository root (keep the `.github/workflows/build-apk.yml` path).
4. Open the repository's **Actions** tab and enable Actions if asked.
5. Run **Build Android APK** (or push to the `main` branch and let it run).
6. Open the completed workflow run, go to **Artifacts**, and download `VishalLinkOpener-debug-apk`.
7. Extract the artifact ZIP; it contains `app-debug.apk`. Open it on your Android phone to install. Android may ask you to allow installs from that browser/file manager.

## Important
- The domain/path is implemented exactly from the agreed pattern, with `https://` added so Android can open it.
- The example domain `www.vishal.com` and PDF path have not been tested for availability. The app will only open the URL; it cannot make a missing PDF exist.
- This is a debug APK for personal testing, not a Play Store release.

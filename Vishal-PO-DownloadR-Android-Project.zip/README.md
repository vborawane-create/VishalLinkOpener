# Vishal PO DownloadR

Android app source for building with GitHub Actions. Features:
- Black and neon-red hacker-style interface with supplied visual reference used as the header artwork.
- Period selector shows YYYY/MM for every month in 2026 and 2027 only.
- Demand number accepts exactly seven digits.
- Builds CSD PO PDF URL as `/YYYY/MM/{demand}_PO_Sign.pdf`.
- View PDF through Google Docs Viewer and download through Android DownloadManager.

Upload this ZIP as `VishalLinkOpener-Android-Project.zip` in the repository. The repository workflow must build the extracted source directly (without overwriting `MainActivity.java`).

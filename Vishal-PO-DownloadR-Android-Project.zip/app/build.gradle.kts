plugins {
    id("com.android.application")
}

android {
    namespace = "com.vishal.linkopener"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vishal.linkopener"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

package com.vishal.linkopener;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import android.text.InputFilter;
import android.text.InputType;
import java.util.*;

public class MainActivity extends Activity {
  private final int RED = Color.rgb(255, 28, 55);
  private final int BG = Color.rgb(7, 7, 10);
  private Spinner period;
  private EditText demand;
  private WebView web;
  private String pdfUrl = "";

  int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
  GradientDrawable panel(int stroke, int fill, int radius) {
    GradientDrawable d = new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radius));
    d.setStroke(dp(1.5f), stroke); return d;
  }
  TextView text(String s, int size, int color, boolean bold) {
    TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
    t.setTypeface(Typeface.create("sans-serif-condensed", bold ? Typeface.BOLD : Typeface.NORMAL));
    return t;
  }
  LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
  void gap(LinearLayout root, int h) { root.addView(new View(this), lp(1,h)); }

  @Override public void onCreate(Bundle b) {
    super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); home();
  }

  void home() {
    ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
    LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
    root.setPadding(dp(18), dp(8), dp(18), dp(24)); scroll.addView(root);

    ImageView hero = new ImageView(this); hero.setImageResource(R.drawable.hacker_header);
    hero.setScaleType(ImageView.ScaleType.CENTER_CROP); hero.setBackground(panel(RED, BG, 18));
    hero.setClipToOutline(true); root.addView(hero, lp(-1, 205));

    TextView title = text("Vishal", 43, Color.WHITE, true); title.setGravity(Gravity.CENTER);
    title.setShadowLayer(dp(8),0,0,RED); root.addView(title, lp(-1,52));
    TextView subtitle = text("PO DownloadR", 31, RED, true); subtitle.setGravity(Gravity.CENTER);
    root.addView(subtitle, lp(-1,42));
    View line = new View(this); line.setBackgroundColor(RED); LinearLayout.LayoutParams linep=lp(-1,2); linep.setMargins(dp(8),dp(9),dp(8),dp(20)); root.addView(line,linep);

    TextView monthLabel = text("SELECT MONTH AND YEAR OF PO", 15, Color.WHITE, true);
    root.addView(monthLabel, lp(-1,30)); gap(root,5);
    period = new Spinner(this); ArrayList<String> options = new ArrayList<>();
    for (int year=2026; year<=2027; year++) for(int m=1;m<=12;m++) options.add(String.format(Locale.US,"%04d/%02d",year,m));
    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, options) {
      @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
        TextView v = (TextView) super.getView(position, convertView, parent); v.setTextColor(Color.WHITE); v.setTextSize(19); v.setPadding(dp(12),dp(6),dp(8),dp(6)); return v;
      }
      @Override public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
        TextView v = (TextView) super.getDropDownView(position, convertView, parent); v.setTextColor(Color.WHITE); v.setTextSize(18); v.setBackgroundColor(Color.rgb(20,10,13)); v.setPadding(dp(14),dp(12),dp(8),dp(12)); return v;
      }
    };
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); period.setAdapter(adapter);
    period.setSelection(9); period.setBackground(panel(RED,Color.rgb(12,10,12),9));
    root.addView(period,lp(-1,58));

    gap(root,20); TextView numberLabel = text("ENTER DEMAND NUMBER 17-",15,Color.WHITE,true); root.addView(numberLabel,lp(-1,30)); gap(root,5);
    demand = new EditText(this); demand.setSingleLine(true); demand.setTextSize(20); demand.setTextColor(Color.WHITE);
    demand.setHintTextColor(Color.GRAY); demand.setHint("8575575"); demand.setInputType(InputType.TYPE_CLASS_NUMBER);
    demand.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7), (source,start,end,dest,dstart,dend)->{
      for(int i=start;i<end;i++) if(!Character.isDigit(source.charAt(i))) return ""; return null;
    }}); demand.setPadding(dp(14),dp(7),dp(14),dp(7)); demand.setBackground(panel(RED,Color.rgb(12,10,12),9)); root.addView(demand,lp(-1,58));

    gap(root,24); Button get = new Button(this); get.setText("⇩   GET PURCHASE ORDER"); get.setTextSize(18); get.setTextColor(Color.WHITE);
    get.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD)); get.setAllCaps(false);
    get.setBackground(panel(RED,Color.rgb(177,7,32),14)); root.addView(get,lp(-1,68)); get.setOnClickListener(v->openPdf());
    gap(root,18); TextView footer=text("CSD  //  PURCHASE ORDER ACCESS",11,Color.GRAY,true); footer.setGravity(Gravity.CENTER); root.addView(footer,lp(-1,26));
    setContentView(scroll);
  }

  void openPdf() {
    String n=demand.getText().toString(); if(n.length()!=7){demand.setError("Enter exactly 7 digits"); return;}
    String selected=period.getSelectedItem().toString(); String[] parts=selected.split("/");
    pdfUrl="https://afd.csdindia.gov.in/wp-content/uploads/"+parts[0]+"/"+parts[1]+"/"+n+"_PO_Sign.pdf";
    viewer();
  }
  void viewer() {
    LinearLayout page=new LinearLayout(this); page.setOrientation(1); page.setBackgroundColor(BG);
    LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(4),dp(3),dp(4),dp(3));
    Button back=new Button(this); back.setText("BACK"); back.setOnClickListener(v->{ if(web!=null){web.destroy();web=null;} home();}); bar.addView(back,lp(80,48));
    TextView heading=text("PURCHASE ORDER",13,RED,true); heading.setGravity(Gravity.CENTER); bar.addView(heading,new LinearLayout.LayoutParams(0,dp(48),1));
    Button download=new Button(this); download.setText("DOWNLOAD"); download.setTextSize(11); download.setOnClickListener(v->downloadPdf()); bar.addView(download,lp(108,48));
    page.addView(bar,lp(-1,54)); web=new WebView(this); web.setBackgroundColor(Color.DKGRAY); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.setWebViewClient(new WebViewClient());
    web.loadUrl("https://docs.google.com/gview?embedded=1&url="+Uri.encode(pdfUrl)); page.addView(web,new LinearLayout.LayoutParams(-1,0,1)); setContentView(page);
  }
  void downloadPdf() {
    try { DownloadManager.Request r=new DownloadManager.Request(Uri.parse(pdfUrl)); r.setTitle("Purchase Order PDF"); r.setDescription("CSD purchase order"); r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"PO_"+demand.getText().toString()+"_PO_Sign.pdf"); ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(r); new AlertDialog.Builder(this).setMessage("Download started. Check Downloads.").setPositiveButton("OK",null).show(); }
    catch(Exception e){new AlertDialog.Builder(this).setMessage("Unable to start download.").setPositiveButton("OK",null).show();}
  }
  @Override public void onBackPressed(){if(web!=null && web.canGoBack())web.goBack(); else home();}
}
